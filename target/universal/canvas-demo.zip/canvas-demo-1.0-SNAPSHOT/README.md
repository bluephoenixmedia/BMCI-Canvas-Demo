BCIF Canvas Demo, leveraging Play / Scala
